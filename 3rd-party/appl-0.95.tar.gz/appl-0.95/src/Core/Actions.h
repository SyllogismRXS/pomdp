#ifndef Actions_H
#define Actions_H

#include <string>
using namespace std;

#include "SymbolSet.h"
#include "IVariableValue.h"
#include "IVariable.h"
#include "VariableContainer.h"


#define Actions VariableContainer 
#define Action ValueSet 

#endif

#ifndef Tuple_H
#define Tuple_H
#include "MObject.h"

namespace momdp
{
	class Tuple :	public MObject
	{
	public:
		Tuple(void)
		{
		}
		virtual ~Tuple(void)
		{
		}
	};
}
#endif

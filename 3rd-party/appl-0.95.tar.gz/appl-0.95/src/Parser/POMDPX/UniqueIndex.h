#ifndef UNIQUEINDEX_H
#define UNIQUEINDEX_H

using namespace std;

class UniqueIndex {

    public:
        int index;
        double value;

};

#endif


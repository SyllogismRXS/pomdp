#include "StateTransitionY.h"

StateTransitionY::StateTransitionY(void)
{
}

StateTransitionY::~StateTransitionY(void)
{
}
